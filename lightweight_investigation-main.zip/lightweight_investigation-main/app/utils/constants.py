INSIGHT_SCOPES = "ins.noti.r ins.suser ins.user"
TENANT_USERNAME = "mvision.e2e+3USW03@gmail.com"
TENANT_PASSWORD = "$y$teM73aM@9"
IAM_TOKEN_URL = "https://iam.cloud.trellix.com/iam/v1.0/token"

INSIGHTS_API_BASE_URL="https://insights.trellix.com/api/v1"
HISTORICAL_API_BASE_URL = "https://sgw.soc.preprod.trellix.com/edrpreprod-search-service/searchservice/80/http/search-service/api/v1"
TENANT_ID = "3474F349-9405-49D0-A01C-284B80D48F88"
#TENANT_ID = "9AC56A98-FD6D-4C4F-BD8B-3E58CAAC30BE"
AUTH = "Basic dXNlcjpVczNyMjAyMA=="
RTS_API_BASE_URL = "https://sgw.soc.preprod.trellix.com/edrpreprodmar/active-response/80/http/api/v1"

DB_URI = "postgresql://postgres:postgres@localhost:5432/postgres?sslmode=disable"